import 'package:flutter/material.dart';

class SaltAnalysis extends StatefulWidget {
  @override
  _SaltAnalysisState createState() => _SaltAnalysisState();
}

class _SaltAnalysisState extends State<SaltAnalysis> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text('This is in salt analysis'),
    );
  }
}
