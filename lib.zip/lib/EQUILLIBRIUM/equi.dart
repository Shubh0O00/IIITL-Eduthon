import 'package:flutter/material.dart';

class Equillibrium extends StatefulWidget {
  @override
  _EquillibriumState createState() => _EquillibriumState();
}

class _EquillibriumState extends State<Equillibrium> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text('This is in Equillibrium'),
    );
  }
}
